#Get Random Number
function cartographer_charon:inv/choose_rand_interval

#writing to temp
data modify storage cartographer_charon:player temp set value {}
data modify storage cartographer_charon:player temp set from storage inv:main inv.all[0]
data remove storage inv:main inv.all[0]

#Apply Vanishing or Shattering or Binding or Haunting
execute if data storage cartographer_charon:player temp.components.minecraft:enchantments.cartographer_custom_enchantments:curse/shattering run function cartographer_charon:item_effects/shattering
execute if data storage cartographer_charon:player temp.components.minecraft:enchantments.cartographer_custom_enchantments:curse/haunting run function cartographer_charon:item_effects/haunting
execute if data storage cartographer_charon:player temp.components.minecraft:enchantments.minecraft:vanishing_curse run function cartographer_charon:item_effects/vanishing
execute if data storage cartographer_charon:player temp.components.minecraft:enchantments.minecraft:binding_curse run scoreboard players set $rand_t dt.var 0

#modify slot
scoreboard players remove $rand_t dt.var 1

#If Drop All Allowed is on, then set the score here to 0
execute if score $drop_all_allowed charon.gmr matches 1.. run scoreboard players set $rand_t dt.var 0

execute if score $rand_t dt.var matches ..0 run function cartographer_charon:inv/never_steal
execute if score $rand_t dt.var matches 1.. run function cartographer_charon:inv/always_steal

#add modified slot to player inventory stack
data modify storage cartographer_charon:player inv append from storage cartographer_charon:player temp

#looping
execute if data storage inv:main inv.all[0] run function cartographer_charon:inv/rec